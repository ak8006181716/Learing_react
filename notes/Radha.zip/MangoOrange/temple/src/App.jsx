
import Home from './components/Home';
import Card from './components/Card';
import { useState } from 'react';
import Footer from './components/Footer';


function App() {
  const [data,setdata]=useState(0);

  return (
    
    <>
     <Home />
      <h1 style={{color:'black', textAlign:'center', fontSize:'40px', top:'7rem', fontWeight:"700"}}>More Temple</h1>
      <br />
      <br />
     <Card/>
     <Footer/>
    </>
  )
}

export default App
